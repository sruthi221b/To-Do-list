# To-Do List Chrome Extension

#### Video Demo
https://www.youtube.com/watch?v=Ym29SK-N2c8

## Description

The To-Do List Chrome Extension is a simple task management tool that allows you to create and manage tasks directly from your Chrome browser.

## Features

- Add tasks: Enter your tasks in the input field and click the "Add" button to add them to your to-do list.
- Remove tasks: Click on a task to remove it from the list.
- Persistent storage: Tasks are saved using Chrome's storage API, so they are available even after closing the browser.

## Installation

1. Clone or download this repository to your local machine.
2. Open Google Chrome and go to `chrome://extensions/`.
3. Enable "Developer mode" (usually a toggle switch at the top-right corner).
4. Click on the "Load unpacked" button and select the directory where you cloned or downloaded the repository.

## Usage

1. Click on the extension icon in the Chrome toolbar to open the popup.
2. Enter a task in the input field and click "Add" to add it to your to-do list.
3. Click on a task to remove it from the list.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

**Note:** This Chrome extension was created as part of a project and is not officially published on the Chrome Web Store.
