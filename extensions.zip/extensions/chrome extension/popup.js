document.addEventListener("DOMContentLoaded", function () {
    const taskInput = document.getElementById("taskInput");
    const addTaskButton = document.getElementById("addTask");
    const taskList = document.getElementById("taskList");
  
    // Load tasks from storage and display them
    chrome.storage.sync.get(["tasks"], function (result) {
      if (result.tasks) {
        result.tasks.forEach((task) => {
          addTaskToList(task);
        });
      }
    });
  
    // Add a task
    addTaskButton.addEventListener("click", function () {
      const taskText = taskInput.value;
      if (taskText) {
        addTaskToList(taskText);
        taskInput.value = "";
  
        chrome.storage.sync.get(["tasks"], function (result) {
          let tasks = result.tasks || [];
          tasks.push(taskText);
          chrome.storage.sync.set({ tasks: tasks });
        });
      }
    });
  
    // Remove a task
    taskList.addEventListener("click", function (event) {
      if (event.target.tagName === "LI") {
        const taskText = event.target.innerText;
        event.target.remove();
  
        chrome.storage.sync.get(["tasks"], function (result) {
          let tasks = result.tasks || [];
          tasks = tasks.filter((task) => task !== taskText);
          chrome.storage.sync.set({ tasks: tasks });
        });
      }
    });
  
    function addTaskToList(taskText) {
      const taskItem = document.createElement("li");
      taskItem.innerText = taskText;
      taskList.appendChild(taskItem);
    }
  });
  